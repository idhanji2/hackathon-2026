import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

type StepId = '1' | '2' | '2a' | '3' | '4' | '5' | '6' | '7' | 'eligible' | 'ineligible';

interface QuestionDef {
  id: StepId;
  title: string;
  type: 'yesno' | 'radio' | 'select' | 'result';
  options?: { value: string; label: string; description?: string }[];
}

export function Home() {
  const [history, setHistory] = useState<StepId[]>(['1']);
  const [ineligibleReason, setIneligibleReason] = useState<string>('');
  
  // State for all answers
  const [answers, setAnswers] = useState<Record<string, string>>({});

  const currentStep = history[history.length - 1];

  const goBack = () => {
    if (history.length > 1) {
      setHistory((prev) => prev.slice(0, -1));
    }
  };

  const startOver = () => {
    setHistory(['1']);
    setAnswers({});
    setIneligibleReason('');
  };

  const handleAnswer = (step: StepId, value: string) => {
    setAnswers((prev) => ({ ...prev, [step]: value }));
    
    // Logic for next step
    if (step === '1') {
      if (value === 'yes') setHistory((prev) => [...prev, '2']);
      else {
        setIneligibleReason("Only individuals (natural persons) may join. Businesses and organizations are not eligible for membership.");
        setHistory((prev) => [...prev, 'ineligible']);
      }
    } else if (step === '2') {
      if (value === 'yes') setHistory((prev) => [...prev, '3']);
      else setHistory((prev) => [...prev, '2a']);
    } else if (step === '2a') {
      if (value === 'yes') setHistory((prev) => [...prev, '3']);
      else {
        setIneligibleReason("The primary member must be a US citizen or resident. Joint members who are not US citizens or residents must have a US-issued photo ID and a US Social Security Card.");
        setHistory((prev) => [...prev, 'ineligible']);
      }
    } else if (step === '3') {
      if (value === 'yes') setHistory((prev) => [...prev, '4']);
      else {
        setIneligibleReason("You must have an existing account at a bank or credit union to be eligible to join.");
        setHistory((prev) => [...prev, 'ineligible']);
      }
    } else if (step === '4') {
      if (value === 'yes') setHistory((prev) => [...prev, '5']);
      else {
        setIneligibleReason("Membership is limited to Muslims who follow the Jafari School (Shia Islam), as well as their qualifying family members who also follow the Jafari School.");
        setHistory((prev) => [...prev, 'ineligible']);
      }
    } else if (step === '5') {
      if (value === 'none') setHistory((prev) => [...prev, '6']);
      else setHistory((prev) => [...prev, 'eligible']);
    } else if (step === '6') {
      if (value === 'yes') setHistory((prev) => [...prev, '7']);
      else {
        setIneligibleReason("To be eligible through the family member path, you must have an immediate or extended family member who is already a Jafari CU member.");
        setHistory((prev) => [...prev, 'ineligible']);
      }
    } else if (step === '7') {
      if (value === 'none') {
        setIneligibleReason("Your relationship to the CU member does not fall within the eligible family member categories.");
        setHistory((prev) => [...prev, 'ineligible']);
      } else {
        setHistory((prev) => [...prev, 'eligible']);
      }
    }
  };

  // Calculate progress (approximate max steps to eligible is 7)
  const isResult = currentStep === 'eligible' || currentStep === 'ineligible';
  const progressValue = isResult ? 100 : Math.min(((history.length) / 7) * 100, 95);

  const getStepContent = (step: StepId) => {
    switch (step) {
      case '1':
        return (
          <YesNoQuestion 
            title="Are you an individual person (not a business or organization)?" 
            onAnswer={(val) => handleAnswer(step, val)} 
          />
        );
      case '2':
        return (
          <YesNoQuestion 
            title="Are you a US citizen or US resident?" 
            onAnswer={(val) => handleAnswer(step, val)} 
          />
        );
      case '2a':
        return (
          <YesNoQuestion 
            title="Are you applying as a joint member with a US citizen or resident, and do you have both a US-issued photo ID (Driver's License or State ID) and a US Social Security Card?" 
            onAnswer={(val) => handleAnswer(step, val)} 
          />
        );
      case '3':
        return (
          <YesNoQuestion 
            title="Do you currently have an account at a bank or credit union?" 
            onAnswer={(val) => handleAnswer(step, val)} 
          />
        );
      case '4':
        return (
          <YesNoQuestion 
            title="Do you follow the Jafari School of Islamic jurisprudence (also known as Shia Islam)?" 
            onAnswer={(val) => handleAnswer(step, val)} 
          />
        );
      case '5':
        return (
          <div className="space-y-6">
            <h2 className="text-2xl font-serif font-medium text-foreground">Are you a community member of one of the following organizations?</h2>
            <RadioGroup onValueChange={(val) => handleAnswer(step, val)} className="space-y-3">
              {[
                { id: 'iec', label: 'Islamic Education Center — Houston, Texas' },
                { id: 'iaba', label: 'Islamic Ahlul Bayt Association — Austin, Texas' },
                { id: 'mont', label: 'Metroplex Organization of Muslims in North Texas (MONT)' },
                { id: 'none', label: 'None of the above' }
              ].map((opt) => (
                <Label
                  key={opt.id}
                  className="flex items-center space-x-3 space-y-0 rounded-lg border border-border bg-card p-4 hover:bg-secondary/50 cursor-pointer transition-colors [&:has([data-state=checked])]:border-primary [&:has([data-state=checked])]:bg-primary/5"
                  data-testid={`option-${opt.id}`}
                >
                  <RadioGroupItem value={opt.id} id={opt.id} />
                  <span className="text-base font-medium">{opt.label}</span>
                </Label>
              ))}
            </RadioGroup>
          </div>
        );
      case '6':
        return (
          <YesNoQuestion 
            title="Do you have a family member who is already a member of Jafari Credit Union?" 
            onAnswer={(val) => handleAnswer(step, val)} 
          />
        );
      case '7':
        return (
          <div className="space-y-6">
            <h2 className="text-2xl font-serif font-medium text-foreground">What is your relationship to the Jafari CU member in your family?</h2>
            <Select onValueChange={(val) => handleAnswer(step, val)}>
              <SelectTrigger className="w-full text-base h-12" data-testid="select-relationship">
                <SelectValue placeholder="Select your relationship" />
              </SelectTrigger>
              <SelectContent>
                {[
                  "Sibling", "Spouse", "Parent", "Child", "Grandparent", "Grandchild",
                  "Sibling of Parent (Uncle/Aunt)", "First Cousin of Parent", "Sibling's Child (Niece/Nephew)",
                  "First Cousin", "First Cousin's Child", "Second Cousin (child of Parent's First Cousin)",
                  "Spouse's Sibling", "Spouse's Parent", "Spouse's First Cousin", "Spouse's Second Cousin",
                  "None of the above"
                ].map((rel) => (
                  <SelectItem key={rel} value={rel === "None of the above" ? "none" : rel}>
                    {rel}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        );
      case 'eligible':
        return (
          <div className="space-y-6 text-center py-8">
            <div className="mx-auto w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mb-6">
              <svg className="w-8 h-8 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
            </div>
            <h2 className="text-3xl font-serif font-semibold text-primary">You are eligible!</h2>
            <p className="text-lg text-muted-foreground max-w-md mx-auto">
              Based on your answers, you appear to meet the eligibility requirements to join Jafari Credit Union.
            </p>
            <div className="bg-secondary/50 p-4 rounded-lg text-sm text-muted-foreground mt-8 text-left">
              <strong>Note:</strong> This is a preliminary eligibility check. Final membership approval is subject to review by Jafari Credit Union.
            </div>
            <Button size="lg" className="w-full mt-6" onClick={startOver} data-testid="btn-start-over">
              Start Over
            </Button>
          </div>
        );
      case 'ineligible':
        return (
          <div className="space-y-6 text-center py-8">
            <div className="mx-auto w-16 h-16 rounded-full bg-destructive/10 flex items-center justify-center mb-6">
              <svg className="w-8 h-8 text-destructive" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </div>
            <h2 className="text-3xl font-serif font-semibold text-destructive">Not Eligible at this Time</h2>
            <p className="text-lg text-muted-foreground max-w-md mx-auto">
              {ineligibleReason}
            </p>
            <Button size="lg" variant="outline" className="w-full mt-8" onClick={startOver} data-testid="btn-start-over-ineligible">
              Start Over
            </Button>
          </div>
        );
    }
  };

  return (
    <div className="min-h-[100dvh] w-full bg-background flex flex-col font-sans">
      <header className="w-full border-b border-border/40 bg-card py-6">
        <div className="container max-w-3xl mx-auto px-4 flex items-center justify-between">
          <div className="flex flex-col">
            <h1 className="text-2xl font-serif font-bold tracking-tight text-primary">Jafari Credit Union</h1>
            <p className="text-sm text-muted-foreground font-medium">Membership Eligibility</p>
          </div>
        </div>
      </header>

      <main className="flex-1 container max-w-2xl mx-auto px-4 py-12 flex flex-col">
        {!isResult && (
          <div className="mb-8">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-muted-foreground">
                Step {history.length}
              </span>
            </div>
            <Progress value={progressValue} className="h-2" />
          </div>
        )}

        <Card className="border-none shadow-xl bg-card relative overflow-hidden">
          <CardHeader className="pb-0 pt-6 px-6">
            {!isResult && history.length > 1 && (
              <Button 
                variant="ghost" 
                size="sm" 
                className="w-fit -ml-2 text-muted-foreground hover:text-foreground mb-4"
                onClick={goBack}
                data-testid="btn-back"
              >
                <ChevronLeft className="w-4 h-4 mr-1" />
                Back
              </Button>
            )}
          </CardHeader>
          <CardContent className="p-6 md:p-10 pt-4">
            <AnimatePresence mode="wait">
              <motion.div
                key={currentStep}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.3, ease: "easeInOut" }}
              >
                {getStepContent(currentStep)}
              </motion.div>
            </AnimatePresence>
          </CardContent>
        </Card>
      </main>
      
      <footer className="w-full py-8 text-center text-muted-foreground text-sm">
        <p>Jafari Credit Union &copy; {new Date().getFullYear()}. All rights reserved.</p>
      </footer>
    </div>
  );
}

function YesNoQuestion({ title, onAnswer }: { title: string; onAnswer: (val: string) => void }) {
  return (
    <div className="space-y-8">
      <h2 className="text-2xl md:text-3xl font-serif font-medium text-foreground leading-snug">{title}</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Button 
          variant="outline" 
          size="lg" 
          className="h-20 text-lg border-2 hover:border-primary hover:bg-primary/5 transition-all"
          onClick={() => onAnswer('yes')}
          data-testid="btn-yes"
        >
          Yes
        </Button>
        <Button 
          variant="outline" 
          size="lg" 
          className="h-20 text-lg border-2 hover:border-primary hover:bg-primary/5 transition-all"
          onClick={() => onAnswer('no')}
          data-testid="btn-no"
        >
          No
        </Button>
      </div>
    </div>
  );
}
